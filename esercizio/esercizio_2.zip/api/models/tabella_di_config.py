from pydantic import BaseModel, Field
from typing import Optional, Literal
from typing import Union, Optional

class tabella_config(BaseModel):
    cassa_in_esaurimento: Optional[int] = None
    prodotto_in_esaurimento: Optional[int] = None
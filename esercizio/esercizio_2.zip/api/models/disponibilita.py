from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime


class Disponibilita(BaseModel):
    codice_macchinetta: Optional[int] = None
    id: Optional[int]
    codice_articolo: Optional[str] = None
    quantita: Optional[int] = None
    prezzo: Optional[int] = None
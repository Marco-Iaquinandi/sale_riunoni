from pydantic import BaseModel, Field
from typing import Optional, Literal

class Giacenze(BaseModel):
    codice_macchinetta: Optional[int] = None
    codice_articolo: Optional[str] = None
    quantita: Optional[int] = None
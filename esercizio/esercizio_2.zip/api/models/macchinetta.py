from pydantic import BaseModel, Field
from typing import Optional, Literal

class Macchinetta(BaseModel):
    id: Optional[int] = None
    indirizzo: Optional[str] = None

class MacchinettaIndirizzo(BaseModel):
    id: Optional[int] = None
    indirizzo: Optional[str] = None
    coordinate: Optional[str] = None
from pydantic import BaseModel, Field
from typing import Optional, Literal

class Prodotto_per_id(BaseModel):
    codice_macchinetta: Optional[int] = None
    codice_articolo: Optional[str] = None
    nome: Optional[str] = None
    prezzo_cent: Optional[int] = None
    quantita: Optional[int] = None
    attivo: Optional[int] = None


class Prodotto_per_solo_id(BaseModel):
    codice_articolo: Optional[str] = None
    nome: Optional[str] = None
    prezzo_cent: Optional[int] = None
    attivo: Optional[int] = None
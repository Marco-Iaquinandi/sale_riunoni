from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime


class Eventi(BaseModel):
    prodotto_id: Optional[int] = None
    in_out: Optional[str] = None
    ita: Optional[str] = None 
    eng: Optional[str] = None
    quantita: Optional[int] = None
    ts: Optional[datetime] = None
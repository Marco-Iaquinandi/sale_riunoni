from pydantic import BaseModel, Field
from typing import Optional, Literal

class Prodotti_All(BaseModel):
    codice_macchinetta: Optional[int] = None
    id: Optional[int]
    codice_articolo: Optional[str] = None
    nome: Optional[str] = None
    prezzo_cent: Optional[int] = None
    quantita: Optional[int] = None
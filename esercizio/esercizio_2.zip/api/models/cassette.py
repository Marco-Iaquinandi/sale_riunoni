from pydantic import BaseModel, Field
from typing import Optional, Literal
from typing import Union, Optional

 
class Cassette(BaseModel):
    id: Optional[int] = None
    id_macchinetta: Optional[int] = None
    totale_euro: Optional[Union[int, float]] = None
    quantita_monete_2: Optional[int] = None
    quantita_monete_1: Optional[int] = None
    quantita_monete_050: Optional[int] = None
    quantita_monete_020: Optional[int] = None
    quantita_monete_010: Optional[int] = None
    
class Cassette_monete(BaseModel):
    totale_euro: Optional[Union[int, float]] = None
    quantita_monete_2: Optional[int] = None
    quantita_monete_1: Optional[int] = None
    quantita_monete_050: Optional[int] = None
    quantita_monete_020: Optional[int] = None
    quantita_monete_010: Optional[int] = None
    
class Cassette_monete_update(BaseModel):
    quantita_monete_2: Optional[int] = None
    quantita_monete_1: Optional[int] = None
    quantita_monete_050: Optional[int] = None
    quantita_monete_020: Optional[int] = None
    quantita_monete_010: Optional[int] = None


class CassetteMonetePercentuale(BaseModel):
    totale: Optional[int] = None
    quantita_monete_2: Optional[int] = None
    quantita_monete_1: Optional[int] = None
    quantita_monete_050: Optional[int] = None
    quantita_monete_020: Optional[int] = None
    quantita_monete_010: Optional[int] = None


 
 
#IMPORT GENERICI
from fastapi import FastAPI,Response
from fastapi.responses import JSONResponse
import api.config as config
import uvicorn
from api.db_utilities import Connection

#IMPORT PRODOTTI
from api.models.prodotti_per_id import Prodotto_per_id
from api.services.read_prodotti_generale import lettura_prodotti
from api.services.read_prodotto_id import lettura_prodotti_id, lettura_prodotti_id_simile
from api.services.post_prodotti import insert_prodotto,insert_giacenza
from api.services.update_prodotto import modifica_prodotto
from api.models.prodotti_per_id import Prodotto_per_solo_id

#IMPORT AVVISI
from api.services.read_eventi import lettura_eventi
from datetime import datetime

#IMPORT GIACENZE
from api.services.update_giacenze import update_giacenze_ricarica
from api.services.update_giacenze import update_giacenze_vendita
from api.models.giacenze import Giacenze
from api.services.delete_giacenza import delete_prodotto

#IMPORT DISPONIBILITA
from api.services.verifica_disponibilità import verifica_disponibilita
from api.models.disponibilita import Disponibilita

#IMPORT CASSETTE
from api.services.read_cassette import lettura_monete
from api.models.cassette import Cassette_monete_update
from api.services.update_cassette import update_cassette_agg_monete,update_cassette_rm_monete
from api.services.macchinetta import lettura_macchinette_per_indirizzo

#IMPORT CONFIG
from api.models.tabella_di_config import tabella_config
from api.services.update_tabella_config import update_tabella_config

app = FastAPI()

@app.get("/prodotti")
def get_prodotti_all(codice_macchinetta):
    return_value = lettura_prodotti(codice_macchinetta)
    if return_value == 'errore':
        return JSONResponse(status_code=404, content={"error": "risorse non trovate"})
    else:
        return return_value
    

@app.get("/prodotti/{codice_articolo}")
def get_prodotti_id(codice_macchinetta,codice_articolo):
    return_value = lettura_prodotti_id(codice_macchinetta,codice_articolo)
    if return_value == 'errore':
        return JSONResponse(status_code=404, content={"error": f"risorsa con codice:({codice_articolo}) non trovata"})
    else:
        return JSONResponse(status_code=200, content=return_value.dict())

@app.get("/prodotti_like/{nome}")
def get_prodotti_id_like(nome,codice_macchinetta: int=None):
    return_value = lettura_prodotti_id_simile(codice_macchinetta,nome)
    if return_value == 'errore':
        return JSONResponse(status_code=404, content={"error": f"risorsa con nome:({nome}) non trovata"})
    else:
        return return_value


@app.get("/macchinetta_like")
def get_macchinetta_ind(indirizzo: str=None):
    return_value = lettura_macchinette_per_indirizzo(indirizzo)
    if return_value == 'errore':
        return JSONResponse(status_code=404, content={"error": f"risorsa con indirizzo:({indirizzo}) non trovata"})
    else:
        return return_value


@app.get("/cassetta/{id_macchinetta}")
def get_monete_disponibili(id_macchinetta):
    return_value = lettura_monete(id_macchinetta)
    if return_value == 'errore':
        return JSONResponse(status_code=404, content={"error": f"risorsa con codice:({id_macchinetta}) non trovata"})
    else:
        return JSONResponse(status_code=200, content=return_value.dict())
    

@app.get("/eventi")
def get_eventi(codice_macchinetta: int,data: datetime=None,inout: str=None):
    return_value = lettura_eventi(codice_macchinetta,data,inout)
    if return_value== 'vuoto':
        return JSONResponse(status_code=404, content={"error": f"Nessun risultato trovato! Controllare che i dati inseriti siano corretti"})
    if return_value == "errore":
        return JSONResponse(status_code=500, content={"error": f"Server non raggiungibile"})
    else:
        return return_value
    
@app.post("/prodotto")
def post_prodotti(item: Prodotto_per_id):
    return_value = insert_prodotto(item)
    if return_value is None:
        return JSONResponse(status_code=400, content={"error": "I parametri che stai cercando di inserire non sono validi"})
    else:
        insert_giacenza(return_value,item)
        return JSONResponse(status_code=200, content={"message": f"dati inseriti correttamente, risorsa con id: {return_value}"})
    

@app.put("/prodotto/{id}")
def put_prodotto(item:Prodotto_per_solo_id, id):
    return_value = modifica_prodotto(item, id)
    if return_value is not None:
        return JSONResponse(status_code=200, content={"message": f"dati modificati correttamente"})
    else:
        return JSONResponse(status_code=404, content={"error": f"Il prodotto che stai provando ad aggiungere non è stato trovato, controlla di aver compilato i campi correttamente"})

    

@app.put("/magazzino/carico")
def put_giacenze(item:Giacenze):
    return_value = update_giacenze_ricarica(item,item.codice_macchinetta,item.codice_articolo,item.quantita)
    if return_value == "UPDATE 1":
        return JSONResponse(status_code=200, content={"message": f"dati modificati correttamente, risorsa con codice:({item.codice_articolo}) aggiunti {item.quantita} pezzi"})
    if return_value == "errore negativo":
        return JSONResponse(status_code=400, content={"error": f"Castrese noi non accettiamo numeri negativi, per favore smettiamola"})
    else:
        return JSONResponse(status_code=404, content={"error": f"Il prodotto che stai provando ad aggiungere con codice:({item.codice_articolo}) non è stato trovato, controlla di aver compilato i campi correttamente"})
    

@app.put("/cassetta/carico")
def put_cassetta_carico(id_macchinetta: int,quantita_moneta_2: int=0,quantita_moneta_1: int=0,quantita_moneta_050: int=0,quantita_moneta_020: int=0,quantita_moneta_010: int=0):
    return_value = update_cassette_agg_monete(id_macchinetta,quantita_moneta_2,quantita_moneta_1,quantita_moneta_050,quantita_moneta_020,quantita_moneta_010)
    print(return_value)
    if quantita_moneta_2 < 0 or quantita_moneta_1 < 0 or  quantita_moneta_050 < 0 or quantita_moneta_020 < 0 or quantita_moneta_020 < 0:
        return {"error": f"Numeri negativi come input non accettati"}
    if return_value == "UPDATE 1":
        return JSONResponse(status_code=200, content={"message": f"Monete aggiunte correttamente"})
    if return_value == "errore negativo":
        return JSONResponse(status_code=400, content={"error": f"Castrese noi non accettiamo numeri negativi, per favore smettiamola"})
    if return_value == "errore_troppo":
        return JSONResponse(status_code=400, content={"error": "Impossibile eseguire l'operazione"})
    else:
        return JSONResponse(status_code=404, content={"error": f"Macchinetta di riferimento non trovata"})
    
    
@app.put("/cassetta/scarico")
def put_cassetta_carico(id_macchinetta: int,quantita_moneta_2: int=0,quantita_moneta_1: int=0,quantita_moneta_050: int=0,quantita_moneta_020: int=0,quantita_moneta_010: int=0):
    if quantita_moneta_2 < 0 or quantita_moneta_1 < 0 or  quantita_moneta_050 < 0 or quantita_moneta_020 < 0 or quantita_moneta_020 < 0:
        return {"error": f"Numeri negativi come input non accettati"}
    return_value = update_cassette_rm_monete(id_macchinetta,quantita_moneta_2,quantita_moneta_1,quantita_moneta_050,quantita_moneta_020,quantita_moneta_010)
    if return_value == "UPDATE 1":
        return JSONResponse(status_code=200, content={"message": f"Monete prelevate correttamente"})
    if return_value == "errore negativo":
        return JSONResponse(status_code=400, content={"error": f"Castrese noi non accettiamo numeri negativi, per favore smettiamola"})
    if return_value == "errore_troppo":
        return JSONResponse(status_code=400, content={"error": f"Impossibile eseguire l'operazione"})
    else:
        print(return_value)
        return JSONResponse(status_code=404, content={"error": f"Macchinetta di riferimento non trovata"})
    
@app.put("/config")
def put_tabella_config(cassa_in_esaurimento: int = None, prodotto_in_esaurimento: int = None):
    return_value = update_tabella_config(cassa_in_esaurimento, prodotto_in_esaurimento)
    if return_value == "UPDATE 1":
        return JSONResponse(status_code=200, content={"message": f"Dati modificati correttamente"})
    else:
        return JSONResponse(status_code=404, content={"error": f"Dati inseriti non validi, riprova con dati validi"})


@app.delete("/giacenza/{id}")
def del_prodotto(prodotto_id,macchinetta_id: int=None):
    return_value = delete_prodotto(prodotto_id,macchinetta_id)
    if return_value == 'DELETE 0':
        return JSONResponse(status_code=400, content={"message": f"Errore! Il prodotto che stai cercando di eliminare non esiste!"})
    if return_value is not None and return_value != 'DELETE 0':
        return JSONResponse(status_code=200, content={"message": f"Prodotto/i eliminato/i correttamente !"})
    else:
        return JSONResponse(status_code=500, content={"error": "il server non è raggiungibile"})

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app,host=config.API_HOST,port=config.API_PORT)
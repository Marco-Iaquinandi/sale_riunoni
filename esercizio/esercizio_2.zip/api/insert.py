import pandas as pd
from db_utilities import Connection
import config

file_csv = "sigarette.csv"
df = pd.read_csv(file_csv)

c = Connection(config.host, config.port, config.database, config.username, config.password)

def insert_prodotto(row):
    sql = """
        INSERT INTO prodotti (codice_articolo, nome, prezzo_cent, attivo)
        VALUES (%s, %s, %s, %s)
        RETURNING id
    """
    params = (row.codice_articolo, row.nome, row.prezzo_cent, row.attivo)
    prodotto_id = c.insert_executor(sql, params)
    return prodotto_id

def insert_giacenza(prodotto_id, quantita):
    sql = """
        INSERT INTO giacenze (prodotto_id, quantita)
        VALUES (%s, %s)
    """
    params = (prodotto_id, quantita)
    c.query_executor(sql, params)
    
for row in df.itertuples(index=False):
    prodotto_id = insert_prodotto(row)
    insert_giacenza(prodotto_id, row.quantita_iniziale)
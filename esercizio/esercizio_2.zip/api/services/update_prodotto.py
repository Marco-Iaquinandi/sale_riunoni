from api.db_utilities import Connection
import api.config as config
from api.models.prodotti_per_id import Prodotto_per_id, Prodotto_per_solo_id
from api.services.read_prodotto_id import lettura_prodotti_solo_id

def modifica_prodotto(item: Prodotto_per_solo_id, id):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    r = lettura_prodotti_solo_id(id)
    head = f"update prodotti set"
    where_condition = f"where id = {id}"
    termini_da_modificare = []
    if item.codice_articolo is not None and item.codice_articolo != r.codice_articolo:
        termini_da_modificare.append(f"codice_articolo = '{item.codice_articolo}'")
    if item.nome is not None and item.nome != r.nome:
        termini_da_modificare.append(f"nome = '{item.nome}'")
    if item.prezzo_cent is not None and item.prezzo_cent != r.prezzo_cent:
        termini_da_modificare.append(f"prezzo_cent = '{item.prezzo_cent}'")
    if item.attivo is not None and item.attivo != r.attivo:
        termini_da_modificare.append(f"attivo = '{item.attivo}'")
    update_string = ", ".join(termini_da_modificare)
    head = f"{head} {update_string} {where_condition}"
    params = (item.codice_articolo, item.nome, item.prezzo_cent, item.attivo)
    try:
        c.query_executor(head,params)
        return id
    except Exception as e:
        print(e)
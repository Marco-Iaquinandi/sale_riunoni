from api.services.read_cassette import lettura_cassetta_somma,c_perc
import operator

def calcola_resto(importo_da_restituire, monete_disponibili, id_macchinetta):
    res = lettura_cassetta_somma(id_macchinetta)
    perc = {
        'quantita_monete_2': 0,
        'quantita_monete_1': 0,
        'quantita_monete_050': 0,
        'quantita_monete_020': 0,
        'quantita_monete_010': 0
    }
    da_saldare = round(importo_da_restituire * 100)
    while da_saldare > 0:
        valori_monete = []
        for x in res:
            if x != 'totale':
                perc[x] = c_perc(res[x],res['totale'])
        
        sorted_x = dict(sorted(perc.items(), key=lambda item: item[1], reverse=True))
        for x in sorted_x:
            if x == 'quantita_monete_2':
                valori_monete.append(2.00)
            if x == 'quantita_monete_1':
                valori_monete.append(1.00)
            if x == 'quantita_monete_050':
                valori_monete.append(0.50)
            if x == 'quantita_monete_020':
                valori_monete.append(0.20)
            if x == 'quantita_monete_010':
                valori_monete.append(0.10)
            
        resto = {}


        for valore in valori_monete:
            valore_centesimi = int(valore * 100)
            nome_moneta = f"{valore}€"
        
            if monete_disponibili.get(nome_moneta) > 0 and da_saldare >= valore_centesimi:
                num_monete = min(
                    da_saldare // valore_centesimi,
                    monete_disponibili[nome_moneta]
                )
            
                if num_monete > 0:
                    resto[nome_moneta] = num_monete
                    da_saldare -= num_monete * valore_centesimi
                    monete_disponibili[nome_moneta] -= num_monete
                    continue

        if da_saldare > 0:
            return "stop_money"
        return resto
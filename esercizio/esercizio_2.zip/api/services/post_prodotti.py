from api.db_utilities import Connection
import api.config as config
from api.models.prodotti_per_id import Prodotto_per_id

c = Connection(config.host, config.port, config.database, config.username, config.password)

def insert_prodotto(item: Prodotto_per_id):
    sql = '''
            insert into prodotti (codice_articolo, nome, prezzo_cent, attivo)
            values(%s,%s,%s,%s)
            returning id
        '''
    params = (item.codice_articolo, item.nome, item.prezzo_cent, item.attivo)
    id_prodotto = c.insert_executor(sql, params)
    return id_prodotto

def insert_giacenza(id_prodotto, item: Prodotto_per_id):
    sql = '''
        insert into giacenze (prodotto_id, id_macchinetta, quantita)
        values (%s, %s, %s)
    '''
    params = (id_prodotto,item.codice_macchinetta, item.quantita)
    c.query_executor(sql, params)

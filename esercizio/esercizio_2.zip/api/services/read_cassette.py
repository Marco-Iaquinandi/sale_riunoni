from api.db_utilities import Connection
import api.config as config
from api.models.cassette import Cassette,Cassette_monete,CassetteMonetePercentuale

def lettura_cassetta(id_macchinetta):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
            select * from cassette c
            where c.id_macchinetta = {id_macchinetta}
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        for x in results:
            cassetta = {
                    "id": x[0],
                    "id_macchinetta": x[1],
                    "totale_euro": x[2],
                    "quantita_monete_2": x[3],
                    "quantita_monete_1": x[4],
                    "quantita_monete_050": x[5],
                    "quantita_monete_020": x[6],
                    "quantita_monete_010": x[7]
                   
                }
        return cassetta
    except Exception as e:
        print(e)
        return "errore"
    

def lettura_monete(id_macchinetta):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
            select * from cassette c
            where c.id_macchinetta = {id_macchinetta}
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        valori_dict = {
                "totale_euro": results[0][2],
                "quantita_monete_2": results[0][3],
                "quantita_monete_1": results[0][4],
                "quantita_monete_050": results[0][5],
                "quantita_monete_020": results[0][6],
                "quantita_monete_010": results[0][7]
            }
        return Cassette_monete(**valori_dict)
    except Exception as e:
        print(e)
        return "errore"
    
    
def c_perc(da_calcolare,rif):
    a = da_calcolare/rif * 100
    return a


def lettura_cassetta_somma(id_macchinetta):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
            select (quantita_monete_2 + quantita_monete_1 + quantita_monete_050 + quantita_monete_020 + quantita_monete_010) as totale, quantita_monete_2 , quantita_monete_1 , quantita_monete_050 , quantita_monete_020 , quantita_monete_010
            from cassette 
            where id_macchinetta = {id_macchinetta}
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        cassetta = {
                'totale': results[0][0],
                'quantita_monete_2': results[0][1],
                'quantita_monete_1': results[0][2],
                'quantita_monete_050': results[0][3],
                'quantita_monete_020': results[0][4],
                'quantita_monete_010': results[0][5]
                }
        return cassetta
    except Exception as e:
        print(e)
        return "errore"
    
    
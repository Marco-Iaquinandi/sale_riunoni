from api.db_utilities import Connection
import api.config as config
from api.models.prodotti_generale import Prodotti_All


def lettura_prodotti(codice_macchinetta):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
    select m.id,p.id,p.codice_articolo,p.nome,p.prezzo_cent,g.quantita from prodotti p
    join giacenze g on g.prodotto_id = p.id
    join macchinette m on m.id = g.id_macchinetta
    where m.id = {codice_macchinetta}
    order by p.id
    '''
    try:
        results = c.fetch_query(query)
        if results == []:
            return "errore"
        prodotti = []
        for x in results:
            valori_dict = {
                    "codice_macchinetta": x[0],
                    "id": x[1],
                    "codice_articolo": x[2],
                    "nome": x[3],
                    "prezzo_cent": x[4],
                    "quantita" : x[5]
                }
            prodotti.append(Prodotti_All(**valori_dict))
        return prodotti
    except Exception as e:
        print(e)
        return "errore"
from api.db_utilities import Connection
import api.config as config

def delete_prodotto(prodotto_id,macchinetta_id):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    if macchinetta_id is not None:
        bas = f'and id_macchinetta = {macchinetta_id}'
    else:
        bas = '--'
    sql = f'''
            delete from giacenze
            where prodotto_id = {prodotto_id} {bas}
        '''
    print(sql)
    try:
        var = c.query_executor2(sql)
        print(var)
        return var
    except Exception as e:
        print (e)
        return "errore"
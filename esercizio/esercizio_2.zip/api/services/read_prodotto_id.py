from api.db_utilities import Connection
import api.config as config
from api.models.prodotti_per_id import Prodotto_per_id, Prodotto_per_solo_id


def lettura_prodotti_id(codice_macchinetta,codice_articolo):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
    select m.id, p.codice_articolo,p.nome,p.prezzo_cent,g.quantita,p.attivo from prodotti p
    join giacenze g on g.prodotto_id = p.id
    join macchinette m on m.id = g.id_macchinetta
    where p.codice_articolo = '{codice_articolo}' and m.id = {codice_macchinetta}
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        valori_dict = {
                "codice_macchinetta": results[0][0],
                "codice_articolo": results[0][1],
                "nome": results[0][2],
                "prezzo_cent": results[0][3],
                "quantita" : results[0][4],
                "attivo": results[0][5]
            }
        return Prodotto_per_id(**valori_dict)
    except Exception as e:
        print(e)
        return "errore"
    



def lettura_prodotti_solo_id(id):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
        select codice_articolo, nome, prezzo_cent, attivo
        from prodotti 
        where id = {id}
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        valori_dict = {
                "codice_articolo": results[0][0],
                "nome": results[0][1],
                "prezzo_cent": results[0][2],
                "attivo": results[0][3]
            }
        return Prodotto_per_solo_id(**valori_dict)
    except Exception as e:
        print(e)
        return "errore"
    

def lettura_prodotti_id_simile(codice_macchinetta,nome):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    if codice_macchinetta is not None:
        p1 = f'and m.id = {codice_macchinetta}'
    else:
        p1 = '--'
    query = f'''
    select m.id, p.codice_articolo,p.nome,p.prezzo_cent,g.quantita,p.attivo from prodotti p
    join giacenze g on g.prodotto_id = p.id
    join macchinette m on m.id = g.id_macchinetta
    where lower(p.nome) like lower('%{nome}%') {p1}
    '''
    print(query)
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        prodotti = []
        for x in results:
            valori_dict = {
                    "id": x[0],
                    "codice_articolo": x[1],
                    "nome": x[2],
                    "prezzo_cent": x[3],
                    "quantita": x[4],
                    "attivo" : x[5]
                }
            prodotti.append(Prodotto_per_solo_id(**valori_dict))
        return prodotti
    except Exception as e:
        print(e)
        return "errore"
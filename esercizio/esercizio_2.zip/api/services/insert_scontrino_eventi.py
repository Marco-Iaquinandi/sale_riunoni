from api.db_utilities import Connection
import api.config as config

def inserimento_scontino(codice_machinetta):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    num = 7
    sql = f'''
            insert into eventi (id_macchinetta, id_anagrafica)
            values({codice_machinetta}, {num})
        '''
    erogazione_scontrino = c.query_executor2(sql)
    return erogazione_scontrino






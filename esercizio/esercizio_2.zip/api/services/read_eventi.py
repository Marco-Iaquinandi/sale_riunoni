from api.db_utilities import Connection
import api.config as config
from datetime import datetime
from api.models.avvisi import Eventi



def lettura_eventi(codice_macchinetta,data,in_out):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    if codice_macchinetta is not None:
        p1 = f'''where e.id_macchinetta = {codice_macchinetta}'''
    else:
        p1 = ' '
    if data is not None:
        ts = f'''and e.ts >= '{data}' '''
    else:
        ts = ' '
    if in_out is not None:
        inout = f'''and lower(a.in_out) = lower('{in_out}') '''
    else:
        inout = ''
    query =f" select e.prodotto_id,a.in_out,a.ita,a.eng,e.quantita,e.ts from eventi e join anagrafica_eventi a on e.id_anagrafica = a.id {p1} {ts} {inout}"
    try:
        results = c.fetch_query(query)
        if results == []:
                return "vuoto"
        lis = []
        for x in results:
            evento = {
                    "prodotto_id": x[0],
                    "in_out": x[1],
                    "ita": x[2],
                    "eng": x[3],
                    "quantita": x[4],
                    "ts": x[5].strftime("%Y-%m-%d %H:%M:%S")
                    }
            lis.append(Eventi(**evento))
        return lis
    except Exception as e:
            print(e)
            return "errore"

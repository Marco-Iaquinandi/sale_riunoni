from api.db_utilities import Connection
from api import config
from api.models.cassette import Cassette,Cassette_monete_update
 
def update_cassette_dare(item: Cassette,id_macchinetta,totale_euro,quantita_moneta_2,quantita_moneta_1,quantita_moneta_050,quantita_moneta_020,quantita_moneta_010):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    head = f"""
        update cassette
            set totale_euro = totale_euro - {totale_euro},
                quantita_monete_2 = quantita_monete_2 - {quantita_moneta_2},
                quantita_monete_1 = quantita_monete_1 - {quantita_moneta_1},
                quantita_monete_050 = quantita_monete_050 - {quantita_moneta_050},
                quantita_monete_020 = quantita_monete_020 - {quantita_moneta_020},
                quantita_monete_010 = quantita_monete_010 - {quantita_moneta_010}
            where id_macchinetta = {id_macchinetta}; 
            """
    try:
        messaggio = c.query_executor2(head)
        return messaggio
    except Exception as e:
        print(e)


def update_cassette_ricevuto(id_macchinetta: int,quantita_moneta_2: int=0,quantita_moneta_1: int=0,quantita_moneta_050: int=0,quantita_moneta_020: int=0,quantita_moneta_010: int=0):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    head = f"""
        update cassette
            set
                quantita_monete_2 = quantita_monete_2 + {quantita_moneta_2},
                quantita_monete_1 = quantita_monete_1 + {quantita_moneta_1},
                quantita_monete_050 = quantita_monete_050 + {quantita_moneta_050},
                quantita_monete_020 = quantita_monete_020 + {quantita_moneta_020},
                quantita_monete_010 = quantita_monete_010 + {quantita_moneta_010}
            where id_macchinetta = {id_macchinetta}; 
            """
    try:
        messaggio = c.query_executor2(head)
        return messaggio
    except Exception as e:
        print(e)
        

def update_cassette_agg_monete(id_macchinetta,quantita_moneta_2,quantita_moneta_1,quantita_moneta_050,quantita_moneta_020,quantita_moneta_010):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    head = f"""
        update cassette
            set quantita_monete_2 = quantita_monete_2 + {quantita_moneta_2},
                quantita_monete_1 = quantita_monete_1 + {quantita_moneta_1},
                quantita_monete_050 = quantita_monete_050 + {quantita_moneta_050},
                quantita_monete_020 = quantita_monete_020 + {quantita_moneta_020},
                quantita_monete_010 = quantita_monete_010 + {quantita_moneta_010}
            where id_macchinetta = {id_macchinetta}; 
            """
    try:
        messaggio = c.query_executor2(head)
        return str(messaggio)
    except Exception as e:
        return "errore_troppo"
        
        
def update_cassette_rm_monete(id_macchinetta,quantita_moneta_2,quantita_moneta_1,quantita_moneta_050,quantita_moneta_020,quantita_moneta_010):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    head = f"""
        update cassette
            set quantita_monete_2 = quantita_monete_2 - {quantita_moneta_2},
                quantita_monete_1 = quantita_monete_1 - {quantita_moneta_1},
                quantita_monete_050 = quantita_monete_050 - {quantita_moneta_050},
                quantita_monete_020 = quantita_monete_020 - {quantita_moneta_020},
                quantita_monete_010 = quantita_monete_010- {quantita_moneta_010}
            where id_macchinetta = {id_macchinetta}; 
            """
    try:
        messaggio = c.query_executor2(head)
        return str(messaggio)
    except Exception as e:
        return "errore_troppo"
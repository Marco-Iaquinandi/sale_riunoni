def calcola_resto(importo_da_restituire, monete_disponibili):

    valori_monete = [2.00, 1.00, 0.50, 0.20, 0.10]

    resto = {}

    importo_centesimi = round(importo_da_restituire * 100)

    for valore in valori_monete:
        valore_centesimi = int(valore * 100)
        nome_moneta = f"{valore}€"
    
        if monete_disponibili.get(nome_moneta) > 0 and importo_centesimi >= valore_centesimi:
            num_monete = min(
                importo_centesimi // valore_centesimi,
                monete_disponibili[nome_moneta]
            )
        
            if num_monete > 0:
                resto[nome_moneta] = num_monete
                importo_centesimi -= num_monete * valore_centesimi
                monete_disponibili[nome_moneta] -= num_monete

    if importo_centesimi > 0:
        return "stop_money"

    return resto
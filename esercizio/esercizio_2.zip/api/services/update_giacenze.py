from api.db_utilities import Connection
import api.config as config
from api.models.giacenze import Giacenze

def update_giacenze_ricarica(item: Giacenze,codice_macchinetta, codice_articolo,quantita):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    head = f"""update giacenze 
                set quantita = quantita + {quantita} 
                where prodotto_id = (select p.id from prodotti p where p.codice_articolo = '{codice_articolo}')
                and id_macchinetta = {codice_macchinetta}    
            """
    if quantita < 0:
        return "errore negativo"
    if codice_macchinetta < 0:
        return "errore negativo"
    try:
        messaggio = c.query_executor2(head)
        return messaggio
    except Exception as e:
        print(e)


def update_giacenze_vendita(item: Giacenze, codice_macchinetta,codice_articolo,quantita):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    head = f"""update giacenze 
                set quantita = quantita - {quantita} 
                where prodotto_id = {codice_articolo}
                and id_macchinetta = {codice_macchinetta}
                """
    try:
        messaggio = c.query_executor2(head)
        return messaggio
    except Exception as e:
        print(e)
from api.db_utilities import Connection
import api.config as config
from api.models.macchinetta import Macchinetta,MacchinettaIndirizzo


def lettura_macchinette():
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
        select m.id, s.long_name
        from macchinette m
        inner join nyc_subway_stations s on m.id = s.gid
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        prodotti = []
        for x in results:
            valori_dict = {
                    "id": x[0],
                    "indirizzo": x[1]
                }
            prodotti.append(Macchinetta(**valori_dict))
        return prodotti
    except Exception as e:
        print(e)
        return "errore"
    

def lettura_macchinette_per_indirizzo(indirizzo):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    if indirizzo is not None:
        bas = f'''where lower(s.long_name) like lower('%{indirizzo}%')'''
    else:
        bas = '--'
    query = f'''
        select m.id, s.long_name 
        from macchinette m
        inner join nyc_subway_stations s on m.id = s.gid
        {bas}
    '''
    try:
        results = c.fetch_query(query)
        if results == []:
            return "errore"
        macchinette = []
        for x in results:
            valori_dict = {
                    "id": x[0],
                    "long_name": x[1]
                }
            macchinette.append(valori_dict)
        return macchinette
    except Exception as e:
        print(e)
        return "errore"
from api.db_utilities import Connection
from api import config
from api.models.tabella_di_config import tabella_config

def update_tabella_config(cassa_in_esaurimento, prodotto_in_esaurimento):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    id = 1
    head = f"update config set"
    where = f"where id = {id}"
    update = []
    if cassa_in_esaurimento is not None:
        update.append(f"cassa_in_esaurimento = {cassa_in_esaurimento}")
    if prodotto_in_esaurimento is not None:
        update.append(f"prodotto_in_esaurimento = {prodotto_in_esaurimento}")
    update_string = ", ".join(update)
    head = f"{head} {update_string} {where}"
    try:
        messaggio = c.query_executor2(head)
        return messaggio
    except Exception as e:
        print(e)
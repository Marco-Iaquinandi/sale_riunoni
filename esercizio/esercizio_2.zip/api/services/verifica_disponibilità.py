from api.db_utilities import Connection
import api.config as config
from api.models.disponibilita import Disponibilita


def verifica_disponibilita(id,codice_macchinetta):
    c = Connection(config.host, config.port, config.database, config.username, config.password)
    query = f'''
    select m.id,p.id,p.codice_articolo, g.quantita, p.prezzo_cent
    from prodotti p
    inner join giacenze g on p.id = g.prodotto_id
    inner join macchinette m on m.id = g.id_macchinetta
    where p.id = {id}
    and m.id = {codice_macchinetta}
    '''
    try:
        results = c.fetch_query(query)
        if results is None:
            return "errore"
        results
        valori_dict = {
                "codice_macchinetta": results[0][0],
                "id": results[0][1],
                "codice_articolo": results[0][2],
                "quantita": results[0][3],
                "prezzo": results[0][4]
                }
        return Disponibilita(**valori_dict)
    except SyntaxError as e:
        print(e)
        return "errore"
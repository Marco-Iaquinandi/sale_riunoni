import logging
import psycopg2
import api.config as conf
import logging.handlers
from logger_sql_configuration import LogDBHandler

TAB_LOG = "logs"
LOG_FILE_PATH = "output_log.log"

def init_logger(name="MY_LOGGER",log_to_db=True, level=logging.DEBUG):
    logging.getLogger().handlers.clear()
    logger = logging.getLogger(name)
    logger.setLevel(level)

    #FILE HANDLER CONFIG
    fh = logging.handlers.RotatingFileHandler(LOG_FILE_PATH, mode='a', maxBytes = 1*1024*1024, backupCount=2, encoding=None, delay=0)
    logger.addHandler(fh)
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    fh.setFormatter(formatter)

    if log_to_db:
        conn = psycopg2.connect(
            host=conf.host,
            user=conf.username,
            port=conf.port,
            password=conf.password,
            dbname=conf.database,
            connect_timeout=30
        )
        cursor = conn.cursor()
        db_handler = LogDBHandler(conn, cursor,TAB_LOG)
        db_handler.setLevel(level)
        logger.addHandler(db_handler)
    return logger

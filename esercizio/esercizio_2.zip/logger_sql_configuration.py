import psycopg2
import time
import logging
import api.config as conf

tabella_log = 'logs'
log_file_path = 'output_log.log'
log_error_level = 'DEBUG'
log_to_db = True

class LogDBHandler(logging.Handler):
    def __init__(self, sql_conn, sql_cursor, db_tbl_log):
        super().__init__()
        self.sql_cursor = sql_cursor
        self.sql_conn = sql_conn
        self.db_tbl_log = db_tbl_log

    def emit(self, record):
        tm = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(record.created))
        log_msg = record.getMessage()

        sql = f"""
            INSERT INTO {self.db_tbl_log} 
            (log_level, log_levelname, log, created_at, created_by) 
            VALUES (%s, %s, %s, %s, %s)
        """
        params = (
            record.levelno,
            record.levelname,
            log_msg,
            tm,
            record.name
        )

        try:
            self.sql_cursor.execute(sql, params)
            self.sql_conn.commit()
        except psycopg2.Error as e:
            print(sql, params)
            print("CRITICAL DB ERROR! Logging to database not possible!", e)

if log_to_db:
    log_conn = psycopg2.connect(
        host=conf.host,
        user=conf.username,
        port=conf.port,
        password=conf.password,
        dbname=conf.database,
        connect_timeout=30
    )
    log_cursor = log_conn.cursor()
    logdb = LogDBHandler(log_conn, log_cursor, tabella_log)

logging.basicConfig(filename=log_file_path)

if log_to_db:
    logging.getLogger('').addHandler(logdb)

log = logging.getLogger('MY_LOGGER')
log.setLevel(log_error_level)
import requests
import json
import logging
import colorama
from colorama import Fore
from api.services.read_prodotti_generale import lettura_prodotti
from api.services.verifica_disponibilità import verifica_disponibilita
from api.services.macchinetta import lettura_macchinette
from api.services.read_cassette import lettura_cassetta,lettura_cassetta_somma,c_perc
from api.services.test_calcola_resto import calcola_resto
from api.services.update_cassette import update_cassette_dare,update_cassette_ricevuto
from api.models.cassette import Cassette,CassetteMonetePercentuale
from api.services.update_giacenze import update_giacenze_vendita
from api.services.insert_scontrino_eventi import inserimento_scontino
colorama.init(autoreset=True)

#LOGGER SETUP
import logger_configuration
logger = logger_configuration.init_logger()

class Richieste():
    def __init__(self):
        pass

    def get_macchinette(self):
        x = lettura_macchinette()
        if x == "errore":
            return "Errore nella ricerca delle macchinette"
        else:
            content = [(item.id,item.indirizzo) for item in x]
            vuoto = [(int(item.id)) for item in x]
            return '\n'.join([f"{id}. {indirizzo}" for id,indirizzo in content]),vuoto

    def get_prodotti(self,codice_macchinetta):
        try:
            x = lettura_prodotti(codice_macchinetta)
            if x == "errore":
                return "Prodotti non recuperati"
            content = [(item.id,item.nome,item.prezzo_cent) for item in x]
            content_id = [(int(item.id)) for item in x]
            return ([f"{id}. {nome}  €{prezzo_cent/100}0" for id,nome,prezzo_cent in content]), content_id
        except Exception:
            return "errore"
        
    def stampa_griglia(self,voci, cols=2, width=38):
        for r in range(0, len(voci), cols):
            print(Fore.WHITE+" ".join(f"{v:<{width}}" for v in voci[r:r+cols]))
 

    def get_disponibilita(self,id,codice_macchinetta):
        try:
            if id is None:
                return 'Nessuna scelta effettuata'
            x = verifica_disponibilita(id,codice_macchinetta)
            return x.quantita
        except Exception as e:
            return f"Inserisci un codice valido! {e}"


    def get_prezzo(self,id: int,codice_macchinetta: int, pezzi: int):
        try:
            if not pezzi:
                return "Inserisci un numero!"
            x = verifica_disponibilita(id,codice_macchinetta)
            risultato = int(x.prezzo)
            pezzi_int = int(pezzi)
            return risultato * pezzi_int
        except Exception as e:
            print(f"Inserisci una quantità valida {e}")
            return "inserisci una quantità valida"
    

        
    def acquisto(self,codice_macchinetta,credito,costo):
        cred = 0+credito
        tot_mac = 0
        monete2 = 0
        monete1 = 0
        monete050 = 0
        monete020 = 0
        monete010 = 0
        cassetta = lettura_cassetta(codice_macchinetta)                  
        monete_in_cassa = {
        "2.0€": cassetta["quantita_monete_2"],
        "1.0€": cassetta["quantita_monete_1"],
        "0.5€": cassetta["quantita_monete_050"],
        "0.2€": cassetta["quantita_monete_020"],
        "0.1€": cassetta["quantita_monete_010"]
    }   

        while True:
            print(Fore.GREEN+f'Prezzo prodotto = €{costo/100}0')
            print(Fore.GREEN+f'Credito = €{cred/100}0')
            prnt = ['1. 2€', '5. 0.10€','2. 1€','6. Conferma Transazione', '3. 0.50€','7. Annulla Transazione','4. 0,20€']
            for r in range(0, len(prnt), 2):
                print(Fore.WHITE+" ".join(f"{v:<{38}}" for v in prnt[r:r+2]))
            f = input(Fore.WHITE+f"Inserisci le monete: ")
            try:
                f = int(f)
            except:
                print(Fore.RED+"Inserisci un numero!")
                continue
            if (f < 1) or (f > 7):
                print(Fore.RED+'Il numero inserito non è disponibile nella selezione, inserire un numero valido')
                continue
            if f == 7:
                print("Sei sicuro di voler uscire ? \n 1. Si \n 2. No")
                while True:
                    try:
                        inp = int(input("Cosa scegli ? \n"))
                    except:
                        print("Hai inserito un carattere non valido, inserisci uno dei due numeri")
                        continue
                    if inp == 1:
                        if cred > 0:
                            cassetta = lettura_cassetta(codice_macchinetta)                  
                            da_restituire = cred / 100
                            res = calcola_resto(da_restituire,monete_in_cassa,codice_macchinetta)

                            for x in res:
                                if x == '2.0€':
                                    monete2 = res["2.0€"]
                                    tot_mac = tot_mac + res["2.0€"]*2
                                if x == '1.0€':
                                    monete1 = res["1.0€"]
                                    tot_mac = tot_mac + res["1.0€"]
                                if x == '0.5€':
                                    monete050 = res["0.5€"]
                                    tot_mac = tot_mac + res["0.5€"]*0.5
                                if x == '0.2€':
                                    monete020 = res["0.2€"]
                                    tot_mac = tot_mac + res["0.2€"]*0.2
                                if x == '0.1€':
                                    monete010 = res["0.1€"]
                                    tot_mac = tot_mac + res["0.1€"]*0.1
                                
                            update_cassette_dare(Cassette,codice_macchinetta,tot_mac,monete2,monete1,monete050,monete020,monete010)


                            print(Fore.GREEN+f"Il resto è di {cred/100}0€, Arrivederci")
                            cred = 0
                            return "stop"
                        else:
                            print("Grazie e arrivederci")
                            cred = 0
                            return "stop"
                    if inp == 2:
                        break
                    else:
                        print("inserisci uno dei due numeri")
                        continue
            if f == 6:
                if cred > costo:
                    if cred - costo > 0:
                        cassetta = lettura_cassetta(codice_macchinetta)                 
                        da_restituire = (cred -costo) / 100
                        res = calcola_resto(da_restituire,monete_in_cassa,codice_macchinetta)
                        if res == 'stop_money':
                            while True:
                                dat = [1,2]
                                print(Fore.RED+"Il credito presente nella cassa non è sufficiente ad erogare il resto! \n 1. Desidero continuare la transazione e prelevare il resto in tabaccheria \n 2. Desidero annullare la transazione")
                                inpu = input("Cosa scegli ? \n")
                                if inpu is None:
                                    print("Inserisci un valore")
                                    continue 
                                try:
                                    inpu = int(inpu)
                                except:
                                    print('inserire un numero')
                                    continue
                                if inpu not in dat:
                                    print("Inserire una scelta tra quelle presenti")
                                    continue
                                if inpu == 1:
                                    break
                                if inpu == 2:
                                    print(Fore.RED+f"Transazione annulla resto credito restituito {cred/100}0€")
                                    return 'stop'

        
                        cred = cred - costo
                        for x in res:
                            if x == '2.0€':
                                monete2 = res["2.0€"]
                                tot_mac = tot_mac + res["2.0€"]*2
                            if x == '1.0€':
                                monete1 = res["1.0€"]
                                tot_mac = tot_mac + res["1.0€"]
                            if x == '0.5€':
                                monete050 = res["0.5€"]
                                tot_mac = tot_mac + res["0.5€"]*0.5
                            if x == '0.2€':
                                monete020 = res["0.2€"]
                                tot_mac = tot_mac + res["0.2€"]*0.2
                            if x == '0.1€':
                                monete010 = res["0.1€"]
                                tot_mac = tot_mac + res["0.1€"]*0.1

                        print(Fore.GREEN+f"Pacchetto acquistato! \n Il tuo credito residuo è pari a: {cred/100}0€. \n Vuoi procedere ad un altro acquisto? \n  1. Procedi ad un nuovo acquisto \n  2. Esci e ricevi il resto: ")
                        while True:
                            scelta = input(Fore.GREEN+f"Cosa scegli ? \n")
                            try:
                                scelta = int(scelta)
                            except:
                                print(Fore.RED+"Inserisci un valore valido")
                                continue
                            if scelta == 1:
                                return cred
                            if scelta == 2:
                                if res == 'stop_money':
                                    inserimento_scontino(codice_macchinetta)
                                    print(Fore.RED+"Recarsi in tabaccheria con scontrino per ritirare il resto, attualmente la macchinetta non può erogare il resto.")
                                else:
                                    print(Fore.WHITE+f"Grazie per averci scelto, il resto e: €{cred/100}0, in monete: {res}")
                                    logger.debug(f"resto erogato: {res}")
                                    res = {x.replace("€"," euro"): y for x, y in res.items()}
                                    update_cassette_dare(Cassette,codice_macchinetta,tot_mac,monete2,monete1,monete050,monete020,monete010)
                                return "stop_post_acquisto"
                            else:
                                print(Fore.RED+"Seleziona una delle due opzioni !")
                                continue
                if cred == costo:
                    cred = cred - costo
                    print(Fore.GREEN+f"Pacchetto acquistato! \n Il tuo credito residuo è pari a: {cred/100}0€. \n Vuoi procedere ad un altro acquisto? \n  1. Procedi ad un nuovo acquisto \n  2. Esci e ricevi il resto: ")
                    while True:
                        scelta = input(Fore.GREEN+f"Cosa scegli ? \n")
                        try:
                            scelta = int(scelta)
                        except:
                            print(Fore.RED+"Inserisci un valore valido")
                            continue
                        if scelta == 1:
                            break
                        if scelta == 2:
                            print(Fore.GREEN+f"Grazie per averci scelto")
                            return "stop"
                        else:
                            print(Fore.RED+"Seleziona una delle due opzioni !")
                            continue
                else:
                    print(Fore.RED+"credito non sufficiente")
                    continue
            if f == 5:
                cred = cred + 10
                monete010_ins = 1
                update_cassette_ricevuto(codice_macchinetta,quantita_moneta_010= monete010_ins)
                continue

            if f == 4:
                cred = cred + 20
                moneta020_ins = 1
                update_cassette_ricevuto(codice_macchinetta,quantita_moneta_020 = moneta020_ins)
                continue

            if f == 3:
                cred = cred + 50
                moneta050_ins = 1
                update_cassette_ricevuto(codice_macchinetta,quantita_moneta_050 = moneta050_ins)
                continue

            if f == 2:
                cred = cred + 100
                moneta1_ins = 1
                update_cassette_ricevuto(codice_macchinetta,quantita_moneta_1 = moneta1_ins)
                continue
            
            if f == 1:
                cred = cred + 200
                moneta2_ins = 1
                update_cassette_ricevuto(codice_macchinetta,quantita_moneta_2=moneta2_ins)
                continue

    def update_giacenza(self,id_macchinetta,id_prodotto,pezzi):
        update_giacenze_vendita(self,id_macchinetta,id_prodotto,pezzi)
-- Database: MagazzinoSpero

-- DROP DATABASE IF EXISTS "MagazzinoSpero";

CREATE DATABASE "MagazzinoSpero"
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Italian_Italy.1252'
    LC_CTYPE = 'Italian_Italy.1252'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

	CREATE EXTENSION postgis;
	SELECT * FROM pg_extension

--Create Tabelle
 
create table config (
	id serial primary key,
	prodotto_in_esaurimento int default 5 check (prodotto_in_esaurimento >= 0) not null,
	cassa_in_esaurimento int default 50 check (cassa_in_esaurimento >= 0) not null
);
 
create table macchinette (
	id serial primary key,
	id_stazione int not null,
	foreign key (id_stazione) references nyc_subway_stations(gid)
);
 
create table cassette (
	id serial primary key,
	id_macchinetta int not null,
	totale_euro numeric not null check (totale_euro >= 0),
	quantita_monete_2 int not null check (quantita_monete_2 >= 0 and quantita_monete_2 <= 150 ),
	quantita_monete_1 int not null check (quantita_monete_1 >= 0  and quantita_monete_1 <= 150),
	quantita_monete_050 int not null check (quantita_monete_050 >= 0 and quantita_monete_050 <= 150),
	quantita_monete_020 int not null check (quantita_monete_020 >= 0 and quantita_monete_020 <= 150),
	quantita_monete_010 int not null check (quantita_monete_010 >= 0 and quantita_monete_010 <= 150),
	foreign key (id_macchinetta) references macchinette(id)
);
 
create table prodotti (
    id serial primary key,
    codice_articolo text not null unique,
    nome text not null,
    prezzo_cent int not null check (prezzo_cent >= 0),
    attivo int not null default 1,
    creato_il timestamp not null default CURRENT_TIMESTAMP
);
 
create table giacenze (
	id serial primary key,
    prodotto_id int,
    id_macchinetta int,
    quantita int not null default 0 check (quantita >= 0),
    foreign key (prodotto_id) references prodotti(id),
    foreign key (id_macchinetta) references macchinette(id)
);
 
create table anagrafica_eventi (
	id serial primary key,
	in_out varchar(3),
	ita varchar(255) not null,
	eng varchar(255) not null
);
 
create table eventi (
    id serial primary key,
    id_macchinetta integer not null,
    prodotto_id int,
    quantita int,
    id_anagrafica int not null,
    ts timestamp not null default date_trunc('hour', CURRENT_TIMESTAMP),
    foreign key (prodotto_id) references prodotti(id),
    foreign key (id_macchinetta) references macchinette(id),
    foreign key (id_anagrafica) references anagrafica_eventi(id)
);

CREATE TABLE logs(
    id serial NOT NULL,
    log_level int NULL,
    log_levelname varchar(32) NULL,
    log text NOT NULL,
    created_at timestamp NOT NULL,
    created_by varchar(144) NOT NULL
);
 
create table evento_monete (
	id serial primary key,
	id_evento int not null,
	quantita_monete_2 int check (quantita_monete_2 >= 0),
	quantita_monete_1 int check (quantita_monete_1 >= 0),
	quantita_monete_050 int check (quantita_monete_050 >= 0),
	quantita_monete_020 int check (quantita_monete_020 >= 0),
	quantita_monete_010 int check (quantita_monete_010 >= 0),
	foreign key (id_evento) references eventi(id)
);
 
-- Trigger Functions
 
create or replace function pippo_baudo()
returns trigger as $$
begin
	if TG_OP = 'UPDATE' then
			insert into eventi (id_macchinetta, prodotto_id, quantita, id_anagrafica)
			values (new.id_macchinetta, new.prodotto_id,
					case
						when new.quantita > old.quantita
						then new.quantita - old.quantita
						when new.quantita < old.quantita
						then old.quantita - new.quantita
					end,
					case
						when new.quantita > old.quantita
						then 1
						when new.quantita < old.quantita
						then 5
					end
				);
			if new.quantita = 0 or new.quantita = (select prodotto_in_esaurimento from config where id = 1) then
				insert into eventi (id_macchinetta, prodotto_id, id_anagrafica)
				values (new.id_macchinetta, new.prodotto_id,
						case
							when new.quantita = 0
							then 9
							when new.quantita = (select prodotto_in_esaurimento from config where id = 1)
							then 8
						end
					);
			end if;
	elsif TG_OP = 'INSERT' then
		insert into eventi (id_macchinetta, prodotto_id, quantita, id_anagrafica)
		values (new.id_macchinetta, new.prodotto_id, new.quantita, 3);
	elsif TG_OP = 'DELETE' then
		insert into eventi (id_macchinetta, prodotto_id,id_anagrafica)
		values (old.id_macchinetta, old.prodotto_id, 7);
	end if;
	return new;
end;
$$ language plpgsql;
 
create or replace trigger pippo
after update or insert or delete
on giacenze
for each row
execute function pippo_baudo();
 
create or replace function controllo_cassa()
returns trigger as $$
declare
    totale_cassa numeric;
begin
    totale_cassa := (new.quantita_monete_2 * 2)
        + (new.quantita_monete_1)
        + (new.quantita_monete_050 * 0.50)
        + (new.quantita_monete_020 * 0.20)
        + (new.quantita_monete_010 * 0.10);
 
    new.totale_euro := totale_cassa;
 
	if new.totale_euro > old.totale_euro then
        insert into eventi (id_macchinetta, id_anagrafica)
        values (new.id_macchinetta, 4);
        insert into evento_monete(id_evento,quantita_monete_2,quantita_monete_1,quantita_monete_050,quantita_monete_020,quantita_monete_010)
        values ((select max(id) from eventi e where e.id_anagrafica = 4),
                new.quantita_monete_2 - old.quantita_monete_2,
                new.quantita_monete_1 - old.quantita_monete_1,
                new.quantita_monete_050 - old.quantita_monete_050,
                new.quantita_monete_020 - old.quantita_monete_020,
                new.quantita_monete_010 - old.quantita_monete_010);
    elsif new.totale_euro < old.totale_euro then
        insert into eventi (id_macchinetta, id_anagrafica)
        values (new.id_macchinetta, 6);
        insert into evento_monete(id_evento,quantita_monete_2,quantita_monete_1,quantita_monete_050,quantita_monete_020,quantita_monete_010)
        values ((select max(id) from eventi e where e.id_anagrafica = 6),
                old.quantita_monete_2 - new.quantita_monete_2,
                old.quantita_monete_1 - new.quantita_monete_1,
                old.quantita_monete_050 - new.quantita_monete_050,
                old.quantita_monete_020 - new.quantita_monete_020,
                old.quantita_monete_010 - new.quantita_monete_010);
    end if;
 
	if totale_cassa <= (select cassa_in_esaurimento from config where id = 1) and totale_cassa != 0 then
        insert into eventi (id_macchinetta, id_anagrafica)
        values (new.id_macchinetta, 10);
    elsif totale_cassa = 0 then
        insert into eventi (id_macchinetta, id_anagrafica)
        values (new.id_macchinetta, 11);
    end if;
 
    return new;
end;
$$ language plpgsql;
 
create or replace trigger trg_cassa
before update
on cassette
for each row
execute function controllo_cassa();
 
-- Insert Tabelle
 
insert into macchinette (id_stazione) values
(4), (5), (6), (7), (13), (15), (17), (23);
 
insert into config (prodotto_in_esaurimento, cassa_in_esaurimento) values
('5', '50');
 
insert into anagrafica_eventi (in_out, ita, eng) values
('IN', 'PRODOTTI CARICATI', 'LOADED PRODUCTS'),
('IN', 'MONETE CARICATE', 'UPLOADED COINS'),
('IN', 'NUOVO PRODOTTO', 'NEW PRODUCT'),
('IN', 'MONETE INSERITE', 'COINS INSERT'),
('OUT', 'VENDITA PRODOTTO', 'PRODUCT SOLD'),
('OUT', 'RESTO EROGATO', 'REST DISPENSED'),
('OUT', 'PRODOTTO ELIMINATO', 'PRODUCT DELETED');
insert into anagrafica_eventi (ita, eng) values
('PRODOTTO IN ESAURIMENTO', 'PRODUCT RUNNING OUT'),
('PRODOTTO ESAURITO', 'PRODUCT SOLD OUT'),
('CASSA IN ESAURIMENTO', 'CASE LOW'),
('CASSA ESAURITA', 'CASE SOLD OUT');
 
insert into cassette (id_macchinetta, totale_euro, quantita_monete_2, quantita_monete_1, quantita_monete_050, quantita_monete_020, quantita_monete_010) values
((select id from macchinette where id_stazione = 4), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 5), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 6), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 7), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 13), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 15), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 17), 380, 100, 100, 100, 100, 100),
((select id from macchinette where id_stazione = 23), 380, 100, 100, 100, 100, 100);
 
insert into prodotti (codice_articolo, nome, prezzo_cent, attivo) values
('MRS-RED-20','Marlboro Rosse 20', 650, 1),
('MRS-GLD-20', 'Marlboro Gold 20', 650, 1),
('MRS-TCH-20', 'Marlboro Touch 20', 620, 1),
('MER-BLU-20', 'Merit Blu 20', 620, 1),
('CHE-BLU-20', 'Chesterfield Blue 20', 550, 1),
('PM-BLU-20', 'Philip Morris Blue 20', 550, 1),
('CAM-BLU-20', 'Camel Blue 20', 600, 1),
('WIN-BLU-20', 'Winston Blue 20', 550, 1),
('LKS-ORG-20', 'Lucky Strike Original 20', 550, 1),
('ROTH-BLU-20', 'Rothmans Blue 20', 530, 1),
('BH-GOLD-20', 'Benson & Hedges Gold 20', 650, 1),
('DIA-BLU-20', 'Diana Blu 20', 530, 1),
('MS-ORI-20', 'MS Originale 20', 530, 1),
('JPS-BLU-20', 'JPS Blue 20', 540, 1),
('GIT-FIL-20', 'Gitanes Filtre 20', 590, 1),
('KENT-BLU-20', 'Kent Blue 20', 650, 1),
('ELX-BLU-20', 'Elixyr Blue 20', 520, 1),
('DUC-RED-20', 'Ducal Red 20', 450, 1),
('FUT-BIA-20', 'Futura Bianca 20', 430, 1),
('ESSE-BLU-20', 'Esse Blue 20', 520, 1);
 
insert into giacenze (prodotto_id, id_macchinetta, quantita) values
(1, 1, 50), (2, 1, 50), (3, 1, 50), (4, 1, 50), (5, 1, 50),
(6, 1, 50), (7, 1, 50), (8, 1, 50), (9, 1, 50), (10, 1, 50),
(11, 1, 50), (12, 1, 50), (13, 1, 50), (14, 1, 50), (15, 1, 50),
(16, 1, 50), (17, 1, 50), (18, 1, 50), (19, 1, 50), (20, 1, 50),
(1, 2, 50), (2, 2, 50), (3, 2, 50), (4, 2, 50), (5, 2, 50),
(6, 2, 50), (7, 2, 50), (8, 2, 50), (9, 2, 50), (10, 2, 50),
(11, 2, 50), (12, 2, 50), (13, 2, 50), (14, 2, 50), (15, 2, 50),
(16, 2, 50), (17, 2, 50), (18, 2, 50), (19, 2, 50), (20, 2, 50),
(1, 3, 50), (2, 3, 50), (3, 3, 50), (4, 3, 50), (5, 3, 50),
(6, 3, 50), (7, 3, 50), (8, 3, 50), (9, 3, 50), (10, 3, 50),
(11, 3, 50), (12, 3, 50), (13, 3, 50), (14, 3, 50), (15, 3, 50),
(16, 3, 50), (17, 3, 50), (18, 3, 50), (19, 3, 50), (20, 3, 50),
(1, 4, 50), (2, 4, 50), (3, 4, 50), (4, 4, 50), (5, 4, 50),
(6, 4, 50), (7, 4, 50), (8, 4, 50), (9, 4, 50), (10, 4, 50),
(11, 4, 50), (12, 4, 50), (13, 4, 50), (14, 4, 50), (15, 4, 50),
(16, 4, 50), (17, 4, 50), (18, 4, 50), (19, 4, 50), (20, 4, 50),
(1, 5, 50), (2, 5, 50), (3, 5, 50), (4, 5, 50), (5, 5, 50),
(6, 5, 50), (7, 5, 50), (8, 5, 50), (9, 5, 50), (10, 5, 50),
(11, 5, 50), (12, 5, 50), (13, 5, 50), (14, 5, 50), (15, 5, 50),
(16, 5, 50), (17, 5, 50), (18, 5, 50), (19, 5, 50), (20, 5, 50),
(1, 6, 50), (2, 6, 50), (3, 6, 50), (4, 6, 50), (5, 6, 50),
(6, 6, 50), (7, 6, 50), (8, 6, 50), (9, 6, 50), (10, 6, 50),
(11, 6, 50), (12, 6, 50), (13, 6, 50), (14, 6, 50), (15, 6, 50),
(16, 6, 50), (17, 6, 50), (18, 6, 50), (19, 6, 50), (20, 6, 50),
(1, 7, 50), (2, 7, 50), (3, 7, 50), (4, 7, 50), (5, 7, 50),
(6, 7, 50), (7, 7, 50), (8, 7, 50), (9, 7, 50), (10, 7, 50),
(11, 7, 50), (12, 7, 50), (13, 7, 50), (14, 7, 50), (15, 7, 50),
(16, 7, 50), (17, 7, 50), (18, 7, 50), (19, 7, 50), (20, 7, 50),
(1, 8, 50), (2, 8, 50), (3, 8, 50), (4, 8, 50), (5, 8, 50),
(6, 8, 50), (7, 8, 50), (8, 8, 50), (9, 8, 50), (10, 8, 50),
(11, 8, 50), (12, 8, 50), (13, 8, 50), (14, 8, 50), (15, 8, 50),
(16, 8, 50), (17, 8, 50), (18, 8, 50), (19, 8, 50), (20, 8, 50);
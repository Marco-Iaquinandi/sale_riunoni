#IMPORT GENERICI
from datetime import datetime,timedelta
from service import Richieste,logger
import random

#IMPORT LETTURA CF
from codicefiscale import codicefiscale
import cv2
import re
import time
from rapidocr_onnxruntime import RapidOCR

cap=cv2.VideoCapture(0)
ra=RapidOCR()
p=re.compile(r'(?<![A-Z0-9])[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z](?![A-Z0-9])')
t=0

#COLORAMA SETUP
import colorama
from colorama import Fore
colorama.init(autoreset=True)

r = Richieste()
a = random.choice(r.get_macchinette()[1])
cred = 0
cod_macchinetta = []
maggiorenne = 0


#SCELTA DELLA MACCHINETTA
while True:
    ir = []
    d = r.get_macchinette()[1]
    while True:  
        scelt = input("Vuoi scegliere una macchinetta specifica oppure scegliere una a caso?\n1) Scegli\n2) Casuale\nInserisic la tua preferenza: ")
        try:
            scelt = int(scelt)
        except:
            logger.error(f"Valore inserito non valido, ( {scelt} )")
            print(Fore.RED+"inserire un valore valido")
            continue
        if scelt == 1:
            print(Fore.WHITE+r.get_macchinette()[0])
            codice_macchinetta = input("Inserisci l'id della macchinetta che vuoi utilizzare: ")
            if codice_macchinetta is None:
                logger.error(f"L'utente non ha inserito valori")
                print(Fore.RED+'inserisci un valore')
                continue
            try:
                codice_macchinetta = int(codice_macchinetta)
            except:
                logger.error(f"Valore inserito non valido nella fase di 'inserisci l'id della macchinetta che vuoi utilizzare', ( {codice_macchinetta} )")
                print(Fore.RED+'inserisci un valore valido')
                continue
            if codice_macchinetta not in d:
                logger.error(f"L'utente ha scelto un id macchinetta non esistente")
                print(Fore.RED+'inserisci una scelta valida')
                continue
            if codice_macchinetta < 0:
                logger.error(f"L'utente ha inserito numeri negativi ({codice_macchinetta})")
                print(Fore.RED+'non accettiamo numeri negativi')
                continue
            else:
                logger.info(f"Macchinetta scelta con successo dal utente, {codice_macchinetta}")
                break
        if scelt == 2:
            codice_macchinetta = a
            logger.info(f"Macchinetta scelta in modo casuale, macchinetta numero {codice_macchinetta}")
            break
        if scelt not in d:
            logger.error(f"Scelta effettuata non presente tra le opzione disponibili, ({scelt})")
            print(Fore.RED+"inserisci una scelta presente nella lista")
            continue
    while 99 not in ir:
        while True:


            #PRINT DELLA LISTA PRODOTTI
            while True:
                print(maggiorenne)
                print(Fore.GREEN+f"Sei nella macchinetta N.{codice_macchinetta}")
                logger.info(f"L'utente e entrato nella macchinetta {codice_macchinetta}")
                risultato = (r.get_prodotti(codice_macchinetta)[0])
                if risultato == "Prodotti non recuperati":
                    print(Fore.RED+risultato)
                    logger.error(f"Errore nel recupero dei prodotti")
                    continue
                if risultato == "errore":
                    logger.error(f"Errore: {risultato}")
                    print(Fore.RED+risultato)
                    continue
                else:
                    r.stampa_griglia(risultato)
                    cod_macchinetta.append(codice_macchinetta)
                    logger.info(f"Prodotti recuperati con successo")
                    break

            while True:
                if maggiorenne == 1:
                    break
                rf=cap.read()
                if (not rf[0]) or time.time()-t<2: continue
                t=time.time()
                out=ra(rf[1])
                s=str(out[0]).upper()
                m=p.search(s)
                if m:
                    cfi = m.group(0)  
                else:
                    print('Presentare il codice fiscale grazie')
                    continue
                if codicefiscale.is_valid(cfi) is True:
                    print("codice fiscale valido, verifica in corso")
                    logger.info("Codice fiscale valido, verifica età in corso")

                else:
                    print("codice fiscale inserito non valido")
                    logger.info("Codice fiscale inserito non valido")
                    continue
                cf = codicefiscale.decode(cfi)
                td= datetime.now()-cf['birthdate']
                    
                if td.days > 6574.5:
                    print(Fore.GREEN+"Età verificata con successo, se abilitato all'acqisto")
                    logger.info("Utente maggiorenne")
                    logger.info("Script avviato con successo")
                    maggiorenne = 1
                    break
                else:
                    print(Fore.RED+"sei minorenne non puoi utilizzare la macchinette")
                    logger.info("utente minorenne, processo bloccato")
                    continue



            #VERIFICA DELLA DISPONIBILITA
            id_ric = []
            while True:
                logger.info("L'utente e entrato nella fase di scelta prodotto/ verifica disponibilita")
                identificativi = r.get_prodotti(cod_macchinetta[0])[1]
                id_richiesto = input(Fore.GREEN+"inserisci il numero abbinato all'articolo interessato:\nSe vuoi uscire dalla fase di acquisto seleziona 99\nInserisci scelta: ")
                if not id_richiesto:
                    print(Fore.RED+"inserisci un numero!")
                    logger.error(f"Valore non valido inserito: ({id_richiesto})")
                    continue
                try:
                    id_richiesto = int(id_richiesto)
                except:
                    print(Fore.RED+"Hai inserito una lettera, inserisci un numero!")
                    logger.error(f"Valore non valido inserito: ({id_richiesto})")
                    continue
                if int(id_richiesto) == 99:
                    print(Fore.GREEN+f"Il resto di {cred/100}0€, Arrivederci")
                    logger.info(f"Processo interrotto su richiesta dell'utente")
                    cred = 0
                    break
                risultato = r.get_disponibilita(id_richiesto,cod_macchinetta[0])
                if risultato == 0:
                    print(Fore.RED+"Siamo spiacenti ma il prodotto che stai cercando di selezionare non è disponibile, per favore scegliere un altro prodotto.")
                    logger.error(f"L'utente ha provato a scegliere un prodotto esaurito")
                    continue
                if risultato == "Nessuna scelta effettuata":
                    print(Fore.RED+risultato)
                    logger.error(f"Valore non valido inserito: ({id_richiesto})")
                    continue
                if risultato == "Inserisci un codice valido!":
                    print(Fore.RED+risultato)
                    logger.error(f"Valore non valido inserito: ({id_richiesto})")
                    continue
                if id_richiesto not in identificativi:
                    print(Fore.RED+"prodotto non esistente")
                    logger.error(f"Valore non valido inserito: ({id_richiesto})")
                    continue
                else:
                    logger.info("Numero pacchetti disponibili restituiti con successo")
                    print(Fore.WHITE+f"Ci sono {risultato} pacchetti disponibili")
                    id_ric.append(id_richiesto)
                    break


            #CALCOLO PREZZO PER QUANTITA
            pr = []
            pez = []
            while True:
                logger.info("L'utente e entrato nella fase di scelta quantita e calcolo prezzo")
                if int(id_richiesto) == 99:
                    break
                pezzi = input(Fore.GREEN+"Quanti pezzi vuoi acquistare?: ")
                disponibili = r.get_disponibilita(id_richiesto,cod_macchinetta[0])
                try:
                    pezzi = int(pezzi)
                except:
                    print(Fore.RED+"Inserisci una quantita valida!")
                    logger.error(f"Valore non valido inserito: ({pezzi})")
                    continue            
                if not pezzi:
                    print("Inserisci qualcosa")
                    logger.error(f"Valore non valido inserito: ({pezzi})")
                    continue
                if pezzi < 1:
                    print(Fore.RED+"Castrese noi non accettiamo numeri negativi, per favore paga le sigarette non come mario")
                    logger.error(f"Valore non valido inserito: ({pezzi})")
                    continue
                risultato = r.get_prezzo(id_ric[0],cod_macchinetta[0], pezzi)
                if risultato == "Inserisci un numero!":
                    print(Fore.RED+risultato)
                    logger.error(f"Valore non valido inserito: ({pezzi})")
                    continue
                if risultato == "Inserisci una quantita valida":
                    print(Fore.RED+risultato)
                    logger.error(f"Valore non valido inserito: ({pezzi})")
                    continue
                if int(pezzi) > int(disponibili):
                    print(Fore.RED+"La quantita richiesta e maggiore della disponibilita")
                    logger.error(f"Valore non valido inserito: ({pezzi})")
                    continue
                else:
                    pr.append(risultato)
                    pez.append(pezzi)
                    break

            if int(id_richiesto) == 99:
                ir.append(99)
                maggiorenne = 0
                break
            
            #FASE DI ACQUISTO
            return_value = r.acquisto(cod_macchinetta[0],cred,pr[0])

            #ACQUISTO AVVENUTO CON SUCCESSO
            if type(return_value) == int:
                cred = cred + return_value
                r.update_giacenza(cod_macchinetta[0],id_ric[0],pez[0])
                logger.info("Operazione di vendita completata con successo")

            #PROCESSO FERMATO DOPO L'ACQUISTO
            if return_value == 'stop_post_acquisto':
                r.update_giacenza(cod_macchinetta[0],id_ric[0],pez[0])
                cred = 0 
                logger.info(f"Acquisto effettuato, processo interrotto.")
                maggiorenne = 0
                t=0
                break
            
            #PROCESSO INTERROTTO
            if return_value == 'stop':
                cred = 0
                maggiorenne = 0
                t=0
                logger.info(f"processo interrotto")
                break



